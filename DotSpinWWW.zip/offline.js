﻿{
	"version": 1603861249,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/merah-sheet0.png",
		"images/background-sheet0.png",
		"images/biru-sheet0.png",
		"images/spinner-sheet0.png",
		"images/pelurubiru-sheet0.png",
		"images/pelurumerah-sheet0.png",
		"images/spawn1-sheet0.png",
		"images/btplay-sheet0.png",
		"images/particles.png",
		"images/efekring-sheet0.png",
		"media/pantul.ogg",
		"media/pecah.ogg",
		"media/effect_firm.ogg",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}